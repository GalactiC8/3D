Surfaces.prototype.singleStripHyperboloid = () => {
    const points = [];
    const edges  = [];
    const polygons = [];
    
    return new Surface(points, edges, polygons);
} 