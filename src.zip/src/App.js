import { useState } from 'react';
import Header from './components/Header/Header';
import Graph2D from './components/Graph2D/Graph2D';
import Graph3D from './components/Graph3D/Graph3D';
import Calc from './components/Calc/Calc';

import './App.css';

const App = () => {
    const [pageName, setPageName] = useState('Graph3D');

    return (<>
        <Header setPageName={setPageName} />
        {pageName === 'Graph2D' && <Graph2D />}
        {pageName === 'Graph3D' && <Graph3D />}
        {pageName === 'Calc' && <Calc />}
    </>);
}

export default App;
