const Func = (props) => {
    const { func } = props;

    const changeFunction = (event) => {
        try {
            let f;
            eval(`f = function(x) {return ${event.target.value};}`);
            func.f = f;
        } catch (e) {
            console.log('ошибка ввода', e);
        }
    }

    return (<div>
        <input onKeyUp={changeFunction} placeholder="f(x)" />
        <input placeholder="color" />
        <input placeholder="width" />
    </div>);
}

export default Func;