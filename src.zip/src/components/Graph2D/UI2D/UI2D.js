import { useState } from "react";
import Func from "./Func/Func";

const UI2D = (props) => {
    const { funcs } = props;
    const [count, setCount] = useState(funcs.length);

    const addFunction = () => {
        funcs.push({
            f: () => 0,
            color: 'black',
            width: 2
        });
        setCount(funcs.length);
    }

    return (<div>
        <button onClick={addFunction} className="beautyButton">+</button>
        <div align="center">
            {funcs.map((func, index) => <Func key={index} func={func} />)}
        </div>
    </div>);
}

export default UI2D;