const Header = (props) => {
    const { setPageName } = props;

    return (<div>
        <button onClick={() => setPageName('Graph2D')}>Графика 2Д</button>
        <button onClick={() => setPageName('Graph3D')}>Графика 3Д</button>
        <button onClick={() => setPageName('Calc')}>Бульбулятор</button>
    </div>);
}

export default Header;