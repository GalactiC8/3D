Surfaces.prototype.KleinBottle = () => {
    const points = [];
    const edges  = [];
    const polygons = [];
    
    return new Surface(points, edges, polygons);
} 