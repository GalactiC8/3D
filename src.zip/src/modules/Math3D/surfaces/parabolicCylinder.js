Surfaces.prototype.parabolicCylinder = () => {
    const points = [];
    const edges  = [];
    const polygons = [];
    
    return new Surface(points, edges, polygons);
} 