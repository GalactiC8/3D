import Graph from "./Graph";

window.requestAnimFrame = (function () {
    return window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        window.oRequestAnimationFrame ||
        window.msRequestAnimationFrame ||
        function (callback) {
            window.setTimeout(callback, 1000 / 60);
        };
})();

const useGraph = (renderScene) => {
    let graph = null;
    let currentFPS = 0;
    let FPS = 0;
    let timestamp = Date.now();

    const animLoop = () => {
        FPS++;
        const currentTimestamp = Date.now();
        if (currentTimestamp - timestamp >= 1000) {
            timestamp = currentTimestamp;
            currentFPS = FPS;
            FPS = 0;
        }
        renderScene(currentFPS);
        window.requestAnimFrame(animLoop);
    }
    
    const getGraph = (options) => {
        graph = new Graph(options);
        animLoop();
        return graph;
    }

    const cancelGraph = () => {
        window.cancelAnimationFrame(animLoop);
        graph = null;
    }

    return [getGraph, cancelGraph];
}

export default useGraph;